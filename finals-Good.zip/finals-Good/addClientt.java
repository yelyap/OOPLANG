import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class addClientt {



     public static void main(String[] args){
         frame();
     }

     public static void frame(){
        DefaultTableModel model;

        JFrame f = new JFrame();

        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f.setLocationRelativeTo(null);

         f.getContentPane().setLayout(new GridBagLayout());
         GridBagConstraints gridConstraints = new GridBagConstraints();

         //Title
         JLabel title = new JLabel("Add a Client");
         title.setFont(new Font("Arial", Font.PLAIN, 25));
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 0;
         gridConstraints.insets = new Insets(10,0,30,0);
         f.getContentPane().add(title, gridConstraints);

         //Labels
         JLabel vehicleType = new JLabel("Name");
         vehicleType.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 1;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(vehicleType, gridConstraints);

         JLabel vehicleNumber = new JLabel("Address");
         vehicleNumber.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 2;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(vehicleNumber, gridConstraints);

         JLabel vehicleManufacturer = new JLabel("Email");
         vehicleManufacturer.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 3;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(vehicleManufacturer, gridConstraints);

         JLabel vehicleModel = new JLabel("Phone Number");
         vehicleModel.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 4;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(vehicleModel, gridConstraints);


         //TextField
         JTextField text1 = new JTextField();
         text1.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 1;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text1, gridConstraints);

         JTextField text2 = new JTextField();
         text2.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 2;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text2, gridConstraints);

         JTextField text3 = new JTextField();
         text3.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 3;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text3, gridConstraints);

         JTextField text4 = new JTextField();
         text4.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 4;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text4, gridConstraints);

         //Buttons
         JButton addButton = new JButton("Add");
         addButton.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 15;
         gridConstraints.gridwidth = 2;
         gridConstraints.insets = new Insets(40,0,0,0);
         f.getContentPane().add(addButton, gridConstraints);

         JButton delete = new JButton("Delete");
         delete.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 15;
         gridConstraints.gridwidth = 3;
         gridConstraints.insets = new Insets(40,10,0,0);
         f.getContentPane().add(delete, gridConstraints);

         JButton clear = new JButton("Clear");
         clear.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 2;
         gridConstraints.gridy = 15;
         gridConstraints.gridwidth = 2;
         gridConstraints.insets = new Insets(40,0,0,0);
         f.getContentPane().add(clear, gridConstraints);
         
         

         JButton exit = new JButton("Exit");
         exit.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 3;
         gridConstraints.gridy = 15;
         gridConstraints.gridwidth = 3;
         gridConstraints.insets = new Insets(40,0,0,0);
         f.getContentPane().add(exit, gridConstraints);




         f.setVisible(true);


         JTable table = new JTable ();

         table.setPreferredScrollableViewportSize(new Dimension(500, 200));
         table.setFillsViewportHeight(true);
         JScrollPane sp = new JScrollPane(table);
         model = new DefaultTableModel();
         Object[] column = {"Name", "Address", "Email", "Phone Number"};
         final Object[] row = new Object[6];
         model.setColumnIdentifiers(column);
         table.setModel(model);
         sp.setViewportView(table);

         addButton.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent arg0) {
                 row[0] = text1.getText();
                 row[1] = text2.getText();
                 row[2] = text3.getText();
                 row[3] = text4.getText();

                 model.addRow(row);

             }
         });
         
         clear.addActionListener(new ActionListener(){
             public void actionPerformed(ActionEvent arg0){
                text1.setText(null);
                text2.setText(null);
                text3.setText(null);
                text4.setText(null);

             }
         });
         
         /*
         delete.addActionListener(new ActionListener(){
             public void actionPerformed(ActionEvent arg0){
                 
             }
         });
         */

         gridConstraints.gridx = 3;
         gridConstraints.gridy = 1;
         gridConstraints.gridheight = 8;
         gridConstraints.insets = new Insets(0,20,0,0);
         f.getContentPane().add(sp, gridConstraints);

         f.pack();


     }
    
}
