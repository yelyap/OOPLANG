import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class addVehicle extends JFrame {
    
    String typeOfCar;
    String numberOfCar; 
    String manufacturerOfCar; 
    String modelOfCar; 
    String transmissionOfCar;
    String colorOfCar;

    JLabel title = new JLabel("Rent a Vehicle");
    JLabel type = new JLabel("Vehicle Type");
    JLabel number = new JLabel("Vehicle No");
    JLabel manufacturer = new JLabel("Manufacturer");
    JLabel model = new JLabel("Model");
    JLabel transmission = new JLabel("Transmission type");
    JLabel color = new JLabel("Vehicle Color");
    
    JTable table = new JTable();
    DefaultTableModel tableModel = (DefaultTableModel)table.getModel();
    
    

    JButton add = new JButton("Add");
    JButton delete = new JButton("Delete");
    JButton clear = new JButton("Clear");
    JButton exit = new JButton("Exit");

    JTextField typeTextField = new JTextField();
    JTextField numberTextField = new JTextField();
    JTextField manufacturerTextField = new JTextField();
    JTextField modelTextField = new JTextField();
    JTextField transmissionTextField = new JTextField();
    JTextField colorTextField = new JTextField();



    public addVehicle(){
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridConstraints = new GridBagConstraints();

        title.setFont(new Font("Arial", Font.PLAIN, 25));
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(10,0,30,0);
        getContentPane().add(title, gridConstraints);
       
        //Buttons
        add.setFont(new Font("Arial", Font.PLAIN, 15));
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 15;
        gridConstraints.insets = new Insets(40,0,0,0);
        getContentPane().add(add, gridConstraints);
        
    
        add.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                addButton(e);
            }
        });
        
        delete.setFont(new Font("Arial", Font.PLAIN, 15));
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 15;
        gridConstraints.insets = new Insets(40,0,0,0);
        getContentPane().add(delete, gridConstraints);
        
        //delete button needs to be cleared
        
        clear.setFont(new Font("Arial", Font.PLAIN, 15));
        gridConstraints.gridx = 3;
        gridConstraints.gridy = 15;
        gridConstraints.insets = new Insets(40,0,0,0);
        getContentPane().add(clear, gridConstraints);
        
        clear.addActionListener (new ActionListener(){
            public void actionPerformed(ActionEvent e){
                clearButton(e);
            }
        });
        
        exit.setFont(new Font("Arial", Font.PLAIN, 15));
        gridConstraints.gridx = 4;
        gridConstraints.gridy = 15;
        gridConstraints.insets = new Insets(40,0,0,0);
        getContentPane().add(exit, gridConstraints);

        //Labels
        type.setFont(new Font("Arial", Font.PLAIN, 15));
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        gridConstraints.insets = new Insets(10,0,0,0);
        getContentPane().add(type, gridConstraints);

        number.setFont(new Font("Arial", Font.PLAIN, 15));
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 2;
        gridConstraints.insets = new Insets(10,0,0,0);
        getContentPane().add(number, gridConstraints);

        manufacturer.setFont(new Font("Arial", Font.PLAIN, 15));
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 3;
        gridConstraints.insets = new Insets(10,0,0,0);
        getContentPane().add(manufacturer, gridConstraints);

        model.setFont(new Font("Arial", Font.PLAIN, 15));
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 4;
        gridConstraints.insets = new Insets(10,0,0,0);
        getContentPane().add(model, gridConstraints);

        transmission.setFont(new Font("Arial", Font.PLAIN, 15));
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 5;
        gridConstraints.insets = new Insets(10,0,0,0);
        getContentPane().add(transmission, gridConstraints);

        color.setFont(new Font("Arial", Font.PLAIN, 15));
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 6;
        gridConstraints.insets = new Insets(10,0,0,0);
        getContentPane().add(color, gridConstraints);

        //TextFields
        typeTextField.setFont(new Font("Arial", Font.PLAIN, 15));
        typeTextField.setColumns(20);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 1;
        gridConstraints.insets = new Insets(10,0,0,0);
        getContentPane().add(typeTextField, gridConstraints);

        numberTextField.setFont(new Font("Arial", Font.PLAIN, 15));
        numberTextField.setColumns(20);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 2;
        gridConstraints.insets = new Insets(10,0,0,0);
        getContentPane().add(numberTextField, gridConstraints);

        manufacturerTextField.setFont(new Font("Arial", Font.PLAIN, 15));
        manufacturerTextField.setColumns(20);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 3;
        gridConstraints.insets = new Insets(10,0,0,0);
        getContentPane().add(manufacturerTextField, gridConstraints);

        modelTextField.setFont(new Font("Arial", Font.PLAIN, 15));
        modelTextField.setColumns(20);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 4;
        gridConstraints.insets = new Insets(10,0,0,0);
        getContentPane().add(modelTextField, gridConstraints);

        transmissionTextField.setFont(new Font("Arial", Font.PLAIN, 15));
        transmissionTextField.setColumns(20);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 5;
        gridConstraints.insets = new Insets(10,0,0,0);
        getContentPane().add(transmissionTextField, gridConstraints);

        colorTextField.setFont(new Font("Arial", Font.PLAIN, 15));
        colorTextField.setColumns(20);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 6;
        gridConstraints.insets = new Insets(10,0,0,0);
        getContentPane().add(colorTextField, gridConstraints);

        //Table
        
        
        String[][] data = {
                { "Kundan Kumar Jha", "4031", "CSE", "4", "5", "6" },
                { "Anand Jha", "6014", "IT","4", "5", "6" },
                {typeOfCar, numberOfCar, manufacturerOfCar, modelOfCar, transmissionOfCar, colorOfCar}
                
        };

        String[] columnNames = { "Type", "Number", "Manufacturer", "Model", "Transmission", "Color" };

        JTable table = new JTable (data, columnNames);
        
        table.setPreferredScrollableViewportSize(new Dimension(500, 200));
        table.setFillsViewportHeight(true);
        JScrollPane sp = new JScrollPane(table);

        gridConstraints.gridx = 3;
        gridConstraints.gridy = 1;
        gridConstraints.gridheight = 8;
        gridConstraints.insets = new Insets(0,20,0,0);
        getContentPane().add(sp, gridConstraints);
        

        pack();
        


    }
    public void addButton(ActionEvent e){
        
        this.typeOfCar = typeTextField.getText();
        this.numberOfCar = numberTextField.getText(); 
        this.manufacturerOfCar = manufacturerTextField.getText(); 
        this.modelOfCar = modelTextField.getText(); 
        this.transmissionOfCar = transmissionTextField.getText();
        this.colorOfCar = colorTextField.getText();
        
        String items[] = {typeOfCar, numberOfCar,manufacturerOfCar,modelOfCar,transmissionOfCar,colorOfCar };
        tableModel.addRow(items);
        table(typeOfCar, numberOfCar,manufacturerOfCar,modelOfCar,transmissionOfCar,colorOfCar);
        
    }
    public void table(String typeOfCar, String numberOfCar,String manufacturerOfCar ,String modelOfCar, String transmissionOfCar, String colorOfCar){
        
    }
    public void clearButton(ActionEvent e){
        JFrame f = new JFrame();
        
        typeTextField.setText(null);
        numberTextField.setText(null);
        manufacturerTextField.setText(null);
        modelTextField.setText(null);
        transmissionTextField.setText(null);
        colorTextField.setText(null);
        
    }

    public static void main(String[] args){
        new addVehicle().show();
        
    }
}