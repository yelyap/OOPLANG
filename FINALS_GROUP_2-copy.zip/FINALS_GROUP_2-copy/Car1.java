
public class Car1 extends mainCar
{
    public Car1(){
        this.vehicleType = "SUV";
        this.vehicleNumber = "AHF-5436";
        this.vehicleManufacturer = "Toyota";
        this.vehicleModel = "Fortuner(2013)";
        this.vehicleTransmission = "Automatic"; 
        this.vehicleColor = "White"; 
        this.vehicleRate = "2000";
        this.vehicleAdvance = "6000";
    }
    
    public String getVehicleType(){
        return vehicleType;
    }
    
    public String getVehicleNumber(){
        return vehicleNumber;
    }
    
    public String getVehicleManufacturer(){
        return vehicleManufacturer;
    }
    
    public String getVehicleModel(){
        return vehicleModel;
    }
    
    public String getVehicleTransmission(){
        return vehicleTransmission;
    }
    
    public String getVehicleColor(){
        return vehicleColor;
    }
    
    public String getVehicleRate(){
        return vehicleRate;
    }
    
    public String getVehicleAdvance(){
        return vehicleAdvance;
    }
    
    
}
