
public class Car3 extends mainCar
{
    public Car3(){
        this.vehicleType = "Sedan";
        this.vehicleNumber = "JND-68483";
        this.vehicleManufacturer = "Mitsubishi";
        this.vehicleModel = "Mirage(2021)";
        this.vehicleTransmission = "Manual"; 
        this.vehicleColor = "Black"; 
        this.vehicleRate = "2500";
        this.vehicleAdvance = "7500";
    }
    
    public String getVehicleType(){
        return vehicleType;
    }
    
    public String getVehicleNumber(){
        return vehicleNumber;
    }
    
    public String getVehicleManufacturer(){
        return vehicleManufacturer;
    }
    
    public String getVehicleModel(){
        return vehicleModel;
    }
    
    public String getVehicleTransmission(){
        return vehicleTransmission;
    }
    
    public String getVehicleColor(){
        return vehicleColor;
    }
    
    public String getVehicleRate(){
        return vehicleRate;
    }
    
    public String getVehicleAdvance(){
        return vehicleAdvance;
    }
    
}
