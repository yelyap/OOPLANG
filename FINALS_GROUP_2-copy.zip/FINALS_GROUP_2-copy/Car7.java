public class Car7 extends mainCar
{
    public Car7(){
        this.vehicleType = "SUV";
        this.vehicleNumber = "NKN-6546";
        this.vehicleManufacturer = "Mitsubishi";
        this.vehicleModel = "Montero Sport(2020)";
        this.vehicleTransmission = "Automatic"; 
        this.vehicleColor = "Silver";
        this.vehicleRate = "4500";
        this.vehicleAdvance = "13500";
    }

    public String getVehicleType(){
        return vehicleType;
    }

    public String getVehicleNumber(){
        return vehicleNumber;
    }

    public String getVehicleManufacturer(){
        return vehicleManufacturer;

    }

    public String getVehicleModel(){
        return vehicleModel;
    }

    public String getVehicleTransmission(){
        return vehicleTransmission;
    }

    public String getVehicleColor(){
        return vehicleColor;
    }
    
    public String getVehicleRate(){
        return vehicleRate;
    }
    
    public String getVehicleAdvance(){
        return vehicleAdvance;
    }

}