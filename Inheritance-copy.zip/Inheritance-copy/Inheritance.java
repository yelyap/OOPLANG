
public class Inheritance
{
    // instance variables - replace the example below with your own
    public static void main(String [] args){
        /*Animal Animal1 = new Animal();
        Animal1.color = "blue";
        Animal1.legs = "4";
        
        Animal1.showInfo(Animal1.color,Animal1.legs);
        */
        
        Dog Dog1 = new Dog("3", "White");
        //Dog1.getDogName();

        
        
    }
        
}
