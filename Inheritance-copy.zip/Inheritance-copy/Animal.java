
public class Animal
{
   public String color;
   public String legs;
   
   public Animal(){
       
   }
   
   public Animal(String color, String legs){
        showInfo(color, legs);
   }
   
   public void showInfo(String color, String legs){
       System.out.println(color);
       System.out.println(legs);
       
   }
}
