
/**
 * Write a description of class Dog here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Dog extends Animal
{
    // instance variables - replace the example below with your own
    public String dogName;
    
    public void getDogName(){
        setDogName(dogName);
 
    }
    public void setDogName(String dogName){
        System.out.println(dogName);
    }
    
    public Dog(String color,String legs){
        super(color, legs);
        this.dogName = "Daemon";
        
        
        System.out.println("My dog's name is "+dogName+ " he has "+color+ " legs and is "+legs);
    }
}
