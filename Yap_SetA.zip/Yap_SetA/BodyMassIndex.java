

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class BodyMassIndex extends JFrame
{
    // instance variables - replace the example below with your own
    
    //JButton
    JButton computeButton = new JButton();
    JButton clearButton = new JButton();
    JButton exitButton = new JButton();
    
    //JLabel
    JLabel heightLabel = new JLabel();
    JLabel feetLabel = new JLabel();
    JLabel inchesLabel = new JLabel();
    JLabel weightLabel = new JLabel();
    JLabel poundsLabel = new JLabel();
    JLabel bmiLabel = new JLabel();
    
    //JTextField
    JTextField feetTextField = new JTextField();
    JTextField inchesTextField = new JTextField();
    JTextField poundsTextField = new JTextField();
    JTextField bmiTextField = new JTextField();
    
    
    public BodyMassIndex(){
        setTitle("BMI Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridBagConstraints = new GridBagConstraints();
        
        //TextFiles
        feetTextField.setText(null);
        feetTextField.setColumns(5);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        getContentPane().add(feetTextField, gridBagConstraints);
        
        inchesTextField.setText(null);
        inchesTextField.setColumns(5);
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 0;
        getContentPane().add(inchesTextField, gridBagConstraints);
        
        poundsTextField.setText(null);
        poundsTextField.setColumns(5);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        getContentPane().add(poundsTextField, gridBagConstraints);
        
        bmiTextField.setText(null);
        bmiTextField.setColumns(5);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        getContentPane().add(bmiTextField, gridBagConstraints);
        
        //Labels
        heightLabel.setText("Height");
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        getContentPane().add(heightLabel, gridBagConstraints);
        
        feetLabel.setText("feet");
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        getContentPane().add(feetLabel, gridBagConstraints);
        
        inchesLabel.setText("inches");
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 0;
        getContentPane().add(inchesLabel, gridBagConstraints);
        
        weightLabel.setText("Weight");
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        getContentPane().add(weightLabel, gridBagConstraints);
        
        poundsLabel.setText("pounds");
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 1;
        getContentPane().add(poundsLabel, gridBagConstraints);
        
        bmiLabel.setText("BMI:");
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        getContentPane().add(bmiLabel, gridBagConstraints);
        
        //Buttons
        computeButton.setText("Compute BMI");
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        getContentPane().add(computeButton, gridBagConstraints);
        computeButton.addActionListener(new ActionListener(){
            public void actionPerformed (ActionEvent e){
            computeMethod(e);
        }
        });
        
        clearButton.setText("Clear");
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 4;
        getContentPane().add(clearButton, gridBagConstraints);
        clearButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                clearMethod(e);
            }
        });
        
        exitButton.setText("Exit");
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 4;
        getContentPane().add(exitButton, gridBagConstraints);
        exitButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                exitMethod(e);
            }
        });
        
        pack();
    }
    
    public void exitMethod(ActionEvent e){
        JFrame f = new JFrame();
        System.exit(0);
    }
    
    public void clearMethod(ActionEvent e){
        JFrame f = new JFrame();
        feetTextField.setText(null);
        inchesTextField.setText(null);
        poundsTextField.setText(null);
        bmiTextField.setText(null);
    }
    
    public void computeMethod (ActionEvent e){
        JFrame f = new JFrame();
        float feet = Float.parseFloat(feetTextField.getText());
        float inches = Float.parseFloat(inchesTextField.getText());
        float pounds = Float.parseFloat(poundsTextField.getText());
        
        float feetBMI = feet * 12;
        float combinedHeight = feetBMI + inches;
        
        float height = combinedHeight * combinedHeight;
        
        float bodyMass = pounds / height;
        float bodyMassIndex = bodyMass * 703;
        
        bmiTextField.setText(" "+String.format("%.2f",bodyMassIndex));
        JOptionPane.showMessageDialog(null,"BMI is: "+String.format("%.2f",bodyMassIndex));
        
    }
    
    public static void main(String [] args){
        new BodyMassIndex().show();
    }
}
