import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class carRental extends JFrame{

    JLabel title = new JLabel();
    JButton carRegistration = new JButton();
    JButton Customer = new JButton();
    JButton rent = new JButton();
    JButton returnCar = new JButton();
    JButton logout = new JButton();
   
   


    public carRental(){
        setTitle("6OOPLANG-Case-Study");
        setSize(400, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridConstraints = new GridBagConstraints();

        title.setText("Vehicle Rental Service");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(10,0,20,0);
        title.setFont(new Font("Cambria", Font.BOLD, 25));
        getContentPane().add(title, gridConstraints);

        carRegistration.setText("Add Vehicle");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        gridConstraints.insets = new Insets(10,0,0,0);
        carRegistration.setFont(new Font("Arial", Font.PLAIN, 15));
        getContentPane().add(carRegistration, gridConstraints);
       
        carRegistration.addActionListener (new ActionListener() {
            public void actionPerformed(ActionEvent e){
                addVehicle(e);
            }
        });
       

        Customer.setText("Add Clients");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 2;
        gridConstraints.insets = new Insets(10,0,0,0);
        Customer.setFont(new Font("Arial", Font.PLAIN, 15));
        getContentPane().add(Customer, gridConstraints);
        
        Customer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                addClient(e);
            }
        });

        rent.setText("Rent");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 3;
        gridConstraints.insets = new Insets(10,0,0,0);
        rent.setFont(new Font("Arial", Font.PLAIN, 15));
        getContentPane().add(rent, gridConstraints);
        
        rent.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                rentVehicle(e);
            }
        });

        returnCar.setText("Return");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 4;
        gridConstraints.insets = new Insets(10,0,0,0);
        returnCar.setFont(new Font("Arial", Font.PLAIN, 15));
        getContentPane().add(returnCar, gridConstraints);
        
        returnCar.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                returnVehicle(e);
            }
        });

        logout.setText("Logout");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 5;
        gridConstraints.insets = new Insets(10,0,0,0);
        logout.setFont(new Font("Arial", Font.PLAIN, 15));
        getContentPane().add(logout, gridConstraints);


    }
    public void returnVehicle(ActionEvent e){
        new returnVehicle().show();
    }
    public void rentVehicle(ActionEvent e){
        new rentVehicle().show();
    }
    public void addClient(ActionEvent e){
        new addClient().show();
    }
    public void addVehicle(ActionEvent e){
        new addVehicle().show();
    }

    public static void main(String[] args){
        new carRental().show();

    }

}
